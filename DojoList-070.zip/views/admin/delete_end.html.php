<h1><?php echo _("Dojo Management System"); ?></h1>

<p><?=h($DojoName)?> <?php echo _("Dojo deleted"); ?></p>

<a href="<?=url_for('dojo')?>"><?php echo _("CONTINUE"); ?></a>