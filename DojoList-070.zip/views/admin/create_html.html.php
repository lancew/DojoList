<h1><?php echo _("Dojo Management System"); ?></h1>
<p><?php echo _("HTML file created."); ?></p>