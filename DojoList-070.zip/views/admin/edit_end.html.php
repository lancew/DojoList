<h1><?php echo _("Dojo Management System"); ?></h1>

<p><?=h($DojoName)?> <?php echo _("Dojo edited"); ?></p>

<a href="<?=url_for('dojo',$DojoName)?>"><?php echo _("CONTINUE"); ?></a>
