<h1><?php echo _("Dojo Management System"); ?></h1>
<p><?php echo _("KML file created."); ?></p>