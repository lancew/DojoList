<h1><?php echo _("Dojo Management System"); ?></h1>
<ul>
<li><a href="<?=url_for('admin','create')?>"><?php echo _("Create a new Dojo"); ?></a></li>
<li><a href="<?=url_for('admin','edit')?>"><?php echo _("Edit a Dojo"); ?></a></li>
<li><a href="<?=url_for('admin','delete')?>"><?php echo _("Delete a Dojo"); ?></a></li>
<p />

</ul>
